includes：程序需要的头文件。
sources：各头文件的源文件以及main.cpp。
p_r_s.h：内含两个枚举类型p_r_s和outcome。
select.h和select.cpp：实现返回 玩家选择动作 和 电脑选择动作 的函数selection_py_player和selection_by_computer。
compare.h和compare.cpp：实现 根据双方动作判断对局结果 的函数compare。
print.h和print.cpp：实现 打印游戏指南的函数prn_help，打印战况信息的函数prn_current 以及打印对局结果的函数report。
main.cpp：主函数，实现游戏运行。