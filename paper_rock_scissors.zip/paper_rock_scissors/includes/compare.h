#include "p_r_s.h"

#ifndef compare_h
#define compare_h

outcome compare(p_r_s player_choice, p_r_s computer_choice);

#endif