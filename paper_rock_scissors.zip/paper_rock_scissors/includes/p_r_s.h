
#ifndef p_r_s_h
#define p_r_s_h

enum p_r_s {rock, scissor, water, fire, paper};
enum outcome {win, lose, tie, error};

#endif