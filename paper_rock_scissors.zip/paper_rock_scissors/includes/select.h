#include <iostream>
#include "p_r_s.h"

#ifndef select_h
#define select_h

//函数：返回玩家输入的类型
p_r_s selection_by_player(int choice);

//函数：返回电脑输入的类型
p_r_s selection_by_computer();

#endif